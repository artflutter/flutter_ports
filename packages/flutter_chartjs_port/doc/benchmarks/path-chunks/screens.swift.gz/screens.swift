import AppKit
import Foundation
let screens = NSScreen.screens.map { s -> [String: Any] in
  var result: [String: Any] = ["id": s.deviceDescription[NSDeviceDescriptionKey("NSScreenNumber")] as? NSNumber ?? 0, "name": s.localizedName, "dpr": s.backingScaleFactor, "x": s.visibleFrame.origin.x, "y": s.visibleFrame.origin.y, "width": s.visibleFrame.width, "height": s.visibleFrame.height]
  if #available(macOS 12.0, *) { result["maxFps"] = s.maximumFramesPerSecond }
  return result
}
let data = try! JSONSerialization.data(withJSONObject: screens, options: [.prettyPrinted, .sortedKeys])
print(String(data: data, encoding: .utf8)!)
