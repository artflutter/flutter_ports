// Copyright (c) 2026 Vasiliy Ditsyak. SPDX-License-Identifier: MIT
// Standalone tests for proposed balanced strip index construction.
#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <random>
#include <vector>

#include "exact_writer.h"
using P = std::array<double, 2>;
using T = std::array<size_t, 3>;
double cross(P a, P b, P p) {
  return (b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0]);
}
int winding(const std::vector<P>& pts, P q) {
  int w = 0;
  for (size_t i = 0; i < pts.size(); i++) {
    P a = pts[i], b = pts[(i + 1) % pts.size()];
    if (a[1] <= q[1]) {
      if (b[1] > q[1] && cross(a, b, q) > 0) w++;
    } else if (b[1] <= q[1] && cross(a, b, q) < 0)
      w--;
  }
  return w;
}
std::vector<T> triangles(size_t n, size_t& indexCount) {
  std::vector<T> out;
  std::vector<impeller::Point> points(n);
  std::vector<uint32_t> indices(Capacity<uint32_t>(n, 1), UINT32_MAX);
  StripPathVertexWriter<uint32_t> writer(points.data(), indices.data(), true);
  for (size_t i = 0; i < n; i++) writer.Write({float(i), 0});
  writer.EndContour();
  indexCount = writer.GetIndexCount();
  assert(indexCount <= indices.size());
  assert(writer.GetPointCount() == n);
  std::vector<size_t> strip;
  for (size_t k = 0; k < indexCount; k++) {
    if (indices[k] == UINT32_MAX) {
      for (size_t i = 2; i < strip.size(); i++) {
        T t = {strip[i - 2], strip[i - 1], strip[i]};
        if (i % 2) std::swap(t[0], t[1]);
        out.push_back(t);
      }
      strip.clear();
    } else {
      assert(indices[k] < n);
      strip.push_back(indices[k]);
    }
  }
  assert(out.size() == n - 2);
  return out;
}
int main() {
  // Overflow selection must fall back without overflowing the capacity.
  for (size_t contours : {0u, 1u, 100u}) {
    const size_t max = std::numeric_limits<size_t>::max() / sizeof(uint32_t);
    for (size_t n : {size_t(1024), max / 2, max - contours}) {
      assert(Capacity<uint32_t>(n, contours) <= max);
    }
  }
  // Multiple contours share the same reservation; small contours keep legacy
  // order.
  for (bool enabled : {false, true}) {
    const std::vector<size_t> lengths = {3, 17, 1023, 1024, 1057, 65535};
    size_t total = 0;
    for (auto n : lengths) total += n;
    std::vector<impeller::Point> points(total);
    std::vector<uint32_t> indices(Capacity<uint32_t>(total, lengths.size()),
                                  UINT32_MAX);
    StripPathVertexWriter<uint32_t> writer(points.data(), indices.data(),
                                           enabled);
    for (auto n : lengths) {
      for (size_t i = 0; i < n; i++) writer.Write({float(i), 0});
      writer.EndContour();
    }
    assert(writer.GetPointCount() == total);
    assert(writer.GetIndexCount() <= indices.size());
  }
  // The 16-bit specialization must not emit the restart sentinel as a vertex.
  for (size_t n : {1024u, 1057u, 65535u}) {
    std::vector<impeller::Point> points(n);
    std::vector<uint16_t> indices(Capacity<uint16_t>(n, 1), UINT16_MAX);
    StripPathVertexWriter<uint16_t> writer(points.data(), indices.data(), true);
    for (size_t i = 0; i < n; i++) writer.Write({float(i), 0});
    writer.EndContour();
    assert(writer.GetIndexCount() <= indices.size());
    size_t vertices = 0;
    for (size_t i = 0; i < writer.GetIndexCount(); i++) {
      if (indices[i] != UINT16_MAX) {
        assert(indices[i] < n);
        vertices++;
      }
    }
    assert(vertices > n);
  }
  size_t capacityCases = 0;
  for (size_t n = 3; n <= 4096; n++) {
    size_t indices;
    triangles(n, indices);
    capacityCases++;
  }
  for (size_t n : {65534u, 65535u, 65536u, 241583u, 1000000u}) {
    size_t indices;
    triangles(n, indices);
    capacityCases++;
  }
  std::mt19937 random(7);
  size_t cases = 0, queries = 0;
  double maximumError = 0;
  for (size_t sample = 0; sample < 170; sample++) {
    const size_t n = sample < 160 ? 3 + random() % 200 : 1024 + random() % 200;
    std::vector<P> polygon;
    for (size_t i = 0; i < n; i++)
      polygon.push_back({double(int(random() % 201) - 100),
                         double(int(random() % 201) - 100)});
    if (sample % 4 == 0) std::reverse(polygon.begin(), polygon.end());
    if (sample % 5 == 0) polygon.push_back(polygon.front());
    if (sample % 7 == 0) polygon[1] = polygon[0];
    if (sample % 11 == 0)
      for (auto& p : polygon) p[1] = 0;
    size_t count;
    auto ts = triangles(polygon.size(), count);
    double expectedArea = 0, actualArea = 0;
    for (size_t i = 0; i < polygon.size(); i++)
      expectedArea +=
          cross({0, 0}, polygon[i], polygon[(i + 1) % polygon.size()]);
    for (auto t : ts)
      actualArea += cross(polygon[t[0]], polygon[t[1]], polygon[t[2]]);
    maximumError = std::max(maximumError, std::abs(expectedArea - actualArea));
    assert(expectedArea == actualArea);
    for (size_t q = 0; q < 200; q++) {
      P point = {double(int(random() % 241) - 120) + .3125,
                 double(int(random() % 241) - 120) + .1875};
      int expected = winding(polygon, point), actual = 0;
      for (auto t : ts)
        actual += winding({polygon[t[0]], polygon[t[1]], polygon[t[2]]}, point);
      assert(expected == actual);
      assert((std::abs(expected) % 2) == (std::abs(actual) % 2));
      queries++;
    }
    cases++;
  }
  std::cout << "PASS capacity=" << capacityCases << " polygons=" << cases
            << " winding_samples=" << queries
            << " signed_area_max_error=" << maximumError << "\n";
}
